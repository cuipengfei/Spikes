﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GildedRoseTest
{
    [TestClass]
    public class GildedRoseTest
    {
        [TestMethod]
        public void TestTheTruth()
        {
            Assert.IsTrue(true);
        }
    }
}
