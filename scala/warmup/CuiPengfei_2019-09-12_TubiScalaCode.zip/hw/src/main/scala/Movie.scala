case class Movie(name: String, rating: Double) {

}
